import user from "../image/user.png";
import user1 from "../image/user1.jpg";

function ContactCard(props) {
  const { id, name, email } = props.list;

  return (
    <div className="ui item row ">
      <img src={user1} className="ui image avatar left floated" />
      <i
        className="trash alternate outline icon right floated"
        style={{ color: "red", marginTop: "20px" }}
        onClick={() => props.clickHandler(id)}
      ></i>
      <div className="content">
        <div className="header">{name}</div>
        <div>{email}</div>
      </div>
    </div>
  );
}

export default ContactCard;
