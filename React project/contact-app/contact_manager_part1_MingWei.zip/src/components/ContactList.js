import ContactCard from "./ContactCard";

function ContactList(props) {
  const deleteContactHandler = (id) => {
    props.getContactId(id);
  };

  return (
    <div className="ui celled list container">
      {props.contacts.map((contact) => (
        <ContactCard list={contact} clickHandler={deleteContactHandler} />
      ))}
    </div>
  );
}

export default ContactList;
